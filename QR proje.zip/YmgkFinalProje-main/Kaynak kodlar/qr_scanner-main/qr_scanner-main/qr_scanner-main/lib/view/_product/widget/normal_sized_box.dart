import 'package:flutter/material.dart';

class NormalSizedBox extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 16.0,
    );
  }
}

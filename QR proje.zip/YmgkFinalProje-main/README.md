<div align="center">
<h3 text="align:center">Hi there 👋<h3>
  <h3 text="align:center">Please scan the Barcode or  click the Google play logo picture
 </h3>
<p>
  </div>
  <div align="center">
  <img style="border:30px;" src="https://i.hizliresim.com/hrq7qdy.png" width="110" height="183">
    <br>
    <br>
 
  
  <a  href="https://play.google.com/store/apps/dev?id=6434216887703327919" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/732/732208.png?w=360" width="120" height="150">
  </a>
  </p>
  
  </div>
  
